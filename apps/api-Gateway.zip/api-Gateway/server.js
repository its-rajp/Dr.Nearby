// apps/api-gateway/server.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createProxyMiddleware } from 'http-proxy-middleware';
import path from 'path';
import { fileURLToPath } from 'url';

// Determine __dirname for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

const app = express();
const PORT = process.env.API_GATEWAY_PORT || 5501;

// CORS: Allow your frontend (http-server on port 8000)
app.use(cors({
  origin: ['http://localhost:8000', 'http://127.0.0.1:8000'],
  credentials: true
}));

// Logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
  next();
});

// Shared error handler for proxy failures
const onProxyError = (err, req, res) => {
  console.error(`❌ Proxy Error [${req.originalUrl}]: Service unavailable.`);
  res.status(502).json({ success: false, message: 'Service unavailable. The backend service is likely down.', error: err.message });
};

// Proxy routes to internal services
app.use('/api/auth', createProxyMiddleware({
  target: `http://localhost:${process.env.PATIENT_SERVICE_PORT || 5502}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/doctor', createProxyMiddleware({
  target: `http://localhost:${process.env.DOCTOR_SERVICE_PORT || 5503}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/admin', createProxyMiddleware({
  target: `http://localhost:${process.env.ADMIN_SERVICE_PORT || 5504}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/appointments', createProxyMiddleware({
  target: `http://localhost:${process.env.CONSULTATION_SERVICE_PORT || 5505}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/consultations', createProxyMiddleware({
  target: `http://localhost:${process.env.CONSULTATION_SERVICE_PORT || 5505}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/notifications', createProxyMiddleware({
  target: `http://localhost:${process.env.CONSULTATION_SERVICE_PORT || 5505}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/lab-tests', createProxyMiddleware({
  target: `http://localhost:${process.env.CONSULTATION_SERVICE_PORT || 5505}`,
  changeOrigin: true,
  onError: onProxyError
}));

app.use('/api/payments', createProxyMiddleware({
  target: `http://localhost:${process.env.CONSULTATION_SERVICE_PORT || 5505}`,
  changeOrigin: true,
  onError: onProxyError
}));

// --- NEW: Proxy all patient-specific features to patient-service (5502) ---
app.use(['/api/health-records', '/api/medicines', '/api/orders'], createProxyMiddleware({
  target: `http://localhost:${process.env.PATIENT_SERVICE_PORT || 5502}`,
  changeOrigin: true,
  pathRewrite: {
    '^/api': '/patient', // Rewrite /api to /patient to match patient-service routes
  },
  onError: onProxyError
}));

// Health check endpoint
app.get('/api', (req, res) => {
  res.json({
    service: 'Dr.Nearby API Gateway',
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// Handle 404 for unknown routes
app.use('*', (req, res) => {
  res.status(404).json({ success: false, message: 'API route not found' });
});

// Start server
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Dr.Nearby API Gateway running on http://localhost:${PORT}`);
});

// Graceful shutdown handler
const shutdown = (signal) => {
  console.log(`${signal} received, shutting down API Gateway...`);
  // Force close all active connections (Node.js 18.2+)
  server.closeAllConnections();
  
  server.close(() => {
    console.log('API Gateway server closed. Exiting process.');
    process.exit(0);
  });
};

// Handle nodemon restarts (SIGUSR2) and other termination signals
process.once('SIGUSR2', () => shutdown('SIGUSR2'));
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));